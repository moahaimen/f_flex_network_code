# Phase 1: Reactive Traffic Engineering

## Final Split

- Train topologies: abilene_backbone, geant_core, ebone, sprintlink, tiscali, vtlwavenet2011
- Validation topologies: chronological val split inside the train topologies only
- In-domain evaluation topologies: abilene_backbone, geant_core, ebone, sprintlink, tiscali
- Unseen generalization topologies: germany50_real
- Germany50 is treated as unseen during DRL training, tuning, and model selection.

## Main Benchmark

No in-domain benchmark table was provided to this report builder.

## Improved DRL Selector Framework

- Teacher-guided pretraining: PPO and DQN are first warm-started from offline teacher labels built from Top-K, bottleneck, sensitivity, and sampled LP-optimal signals.
- Curriculum congestion training: training proceeds through C2, then C3, then mixed C1/C2/C3 stages with progressively richer reward terms.
- Dual-gate inference: PPO and DQN each propose Top-Kcrit OD selections; both are evaluated through the same LP layer; the lower-MLU candidate is chosen, with disturbance and delay tie-breakers.

## DRL Ablation Table

| variant | avg_mean_mlu | avg_p95_mlu | avg_mean_delay | avg_mean_disturbance |
| --- | --- | --- | --- | --- |
| PPO baseline | 453.121505 | 519.167749 | 267.117235 | 0.105176 |
| DQN baseline | 440.868995 | 497.542033 | 267.819460 | 0.086187 |
| PPO + pretraining | 447.997204 | 533.486197 | 268.217961 | 0.037549 |
| DQN + pretraining | 451.650104 | 527.838193 | 268.504012 | 0.041161 |
| PPO + pretraining + curriculum | 453.329282 | 539.871686 | 270.221258 | 0.051314 |
| DQN + pretraining + curriculum | 451.650104 | 527.838193 | 268.504012 | 0.041161 |
| Dual-Gate final | 450.492818 | 534.295109 | 269.181001 | 0.047580 |

## LP-optimal Interpretation

- Use the wording `sampled LP-optimal upper bound` or `runtime-capped LP upper bound` in the thesis/report.
- This row comes from a full multicommodity-flow LP on sampled evaluation steps only, with a CBC runtime cap. In the full Phase-1 run it is executed only on tractable SNDlib topologies (Abilene and GEANT).

## Reproduced Literature Baselines

- `ERODRL`, `FlexDATE`, `CFR-RL`, and `FlexEntry` are faithful simplified reproductions, not exact official implementations.
| method | note |
| --- | --- |
| cfrrl | Simplified reproduced baseline: bottleneck selector reweighted by failure exposure when failures are active. |
| erodrl | Simplified reproduced baseline: sensitivity scoring with selection stickiness to approximate DRL rerouting. |
| flexdate | Simplified reproduced baseline: demand-and-delay weighted Top-K selector with LP refinement. |
| flexentry | Simplified reproduced baseline: sensitivity selector with a conservative reconfiguration budget. |

## Dataset Execution Status

- `germany50_real` was executed as the unseen generalization topology.
- `germany50_topologyzoo_real` was not executed because the external real traffic matrix file is missing.
- `cernet_real` was not executed because the external real traffic matrix file is missing.

## Generalization on Unseen Topologies

- Final generalization uses the corrected unseen split; `germany50_real` does not appear in `train_topologies` or `eval_topologies` in the corrected full config.
| train_scope | dataset | display_name | method | mean_mlu | mean_delay | mean_disturbance |
| --- | --- | --- | --- | --- | --- | --- |
| abilene_backbone,geant_core,ebone,sprintlink,tiscali,vtlwavenet2011 | germany50 | Germany50 (SNDlib real traffic) | flexdate | 21.935045 | 530.883367 | 0.216007 |
| abilene_backbone,geant_core,ebone,sprintlink,tiscali,vtlwavenet2011 | germany50 | Germany50 (SNDlib real traffic) | bottleneck | 22.214560 | 531.957167 | 0.171446 |
| abilene_backbone,geant_core,ebone,sprintlink,tiscali,vtlwavenet2011 | germany50 | Germany50 (SNDlib real traffic) | cfrrl | 22.214560 | 531.957167 | 0.171446 |
| abilene_backbone,geant_core,ebone,sprintlink,tiscali,vtlwavenet2011 | germany50 | Germany50 (SNDlib real traffic) | topk | 22.248924 | 535.951439 | 0.190347 |
| abilene_backbone,geant_core,ebone,sprintlink,tiscali,vtlwavenet2011 | germany50 | Germany50 (SNDlib real traffic) | erodrl | 23.953543 | 536.551033 | 0.156833 |
| abilene_backbone,geant_core,ebone,sprintlink,tiscali,vtlwavenet2011 | germany50 | Germany50 (SNDlib real traffic) | sensitivity | 24.525642 | 536.962921 | 0.204778 |
| abilene_backbone,geant_core,ebone,sprintlink,tiscali,vtlwavenet2011 | germany50 | Germany50 (SNDlib real traffic) | flexentry | 24.932882 | 540.817461 | 0.169928 |
| abilene_backbone,geant_core,ebone,sprintlink,tiscali,vtlwavenet2011 | germany50 | Germany50 (SNDlib real traffic) | our_drl_dqn | 31.747248 | 520.607758 | 0.024820 |
| abilene_backbone,geant_core,ebone,sprintlink,tiscali,vtlwavenet2011 | germany50 | Germany50 (SNDlib real traffic) | our_drl_dual_gate | 31.748217 | 520.613625 | 0.022927 |
| abilene_backbone,geant_core,ebone,sprintlink,tiscali,vtlwavenet2011 | germany50 | Germany50 (SNDlib real traffic) | our_drl_ppo | 31.985414 | 520.683206 | 0.018043 |
| abilene_backbone,geant_core,ebone,sprintlink,tiscali,vtlwavenet2011 | germany50 | Germany50 (SNDlib real traffic) | ecmp | 32.198400 | 520.703500 | 0.000000 |
| abilene_backbone,geant_core,ebone,sprintlink,tiscali,vtlwavenet2011 | germany50 | Germany50 (SNDlib real traffic) | ospf | 38.270430 | 519.710429 | 0.000000 |
