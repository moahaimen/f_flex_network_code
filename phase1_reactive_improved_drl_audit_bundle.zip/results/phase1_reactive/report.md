# Phase 1: Reactive Traffic Engineering

## Main Benchmark

| dataset | display_name | method | mean_mlu | p95_mlu | mean_delay | throughput | mean_disturbance | mean_gap_pct | mean_achieved_pct | decision_time_ms | training_time_sec | convergence_rate |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| abilene | Abilene Backbone (SNDlib) | sensitivity | 0.044357 | 0.049386 | 5.246247 | 1.000000 | 0.119321 | -0.000001 | 100.000001 | 23.844123 | nan | nan |
| abilene | Abilene Backbone (SNDlib) | flexdate | 0.044357 | 0.049386 | 5.219795 | 1.000000 | 0.087058 | -0.000001 | 100.000001 | 23.227926 | nan | nan |
| abilene | Abilene Backbone (SNDlib) | our_drl_ppo | 0.044357 | 0.049386 | 5.320662 | 1.000000 | 0.127507 | -0.000001 | 100.000001 | 28.993774 | 274.299596 | 0.687500 |
| abilene | Abilene Backbone (SNDlib) | bottleneck | 0.044357 | 0.049386 | 5.242065 | 1.000000 | 0.078852 | -0.000001 | 100.000001 | 23.729338 | nan | nan |
| abilene | Abilene Backbone (SNDlib) | cfrrl | 0.044357 | 0.049386 | 5.242065 | 1.000000 | 0.078852 | -0.000001 | 100.000001 | 23.903826 | nan | nan |
| abilene | Abilene Backbone (SNDlib) | erodrl | 0.044357 | 0.049386 | 5.247412 | 1.000000 | 0.122762 | -0.000001 | 100.000001 | 23.974338 | nan | nan |
| abilene | Abilene Backbone (SNDlib) | topk | 0.044357 | 0.049386 | 5.270124 | 1.000000 | 0.113334 | -0.000000 | 100.000000 | 23.398500 | nan | nan |
| abilene | Abilene Backbone (SNDlib) | LP-optimal upper bound (sampled, runtime-capped) | 0.044357 | 0.049386 | 4.917563 | 1.000000 | 0.029863 | 0.000000 | 100.000000 | 72.450824 | nan | nan |
| abilene | Abilene Backbone (SNDlib) | our_drl_dqn | 0.044362 | 0.049386 | 5.334216 | 1.000000 | 0.085394 | 0.010873 | 99.989154 | 26.939842 | 189.583471 | 0.687500 |
| abilene | Abilene Backbone (SNDlib) | our_drl_dual_gate | 0.044362 | 0.049386 | 5.336751 | 1.000000 | 0.084969 | 0.010873 | 99.989154 | 78.380019 | 463.883067 | 0.687500 |
| abilene | Abilene Backbone (SNDlib) | flexentry | 0.044431 | 0.049386 | 5.447594 | 1.000000 | 0.129012 | 0.175150 | 99.832918 | 23.490244 | nan | nan |
| abilene | Abilene Backbone (SNDlib) | ospf | 0.065111 | 0.079279 | 4.886218 | 1.000000 | 0.000000 | 46.248790 | 68.837030 | 0.000000 | nan | nan |
| abilene | Abilene Backbone (SNDlib) | ecmp | 0.098050 | 0.115486 | 4.902387 | 1.000000 | 0.000000 | 120.569564 | 45.504520 | 0.000000 | nan | nan |
| geant | GEANT Core (SNDlib) | LP-optimal upper bound (sampled, runtime-capped) | 0.102411 | 0.120453 | 5.360168 | 1.000000 | 0.159139 | 0.000000 | 100.000000 | 407.819509 | nan | nan |
| geant | GEANT Core (SNDlib) | bottleneck | 0.146292 | 0.170375 | 5.986703 | 1.000000 | 0.172115 | 43.140854 | 69.878578 | 27.521493 | nan | nan |
| geant | GEANT Core (SNDlib) | cfrrl | 0.146292 | 0.170375 | 5.986703 | 1.000000 | 0.172115 | 43.140854 | 69.878578 | 27.573809 | nan | nan |
| geant | GEANT Core (SNDlib) | our_drl_dqn | 0.147808 | 0.172130 | 6.075701 | 1.000000 | 0.035826 | 44.562761 | 69.184215 | 36.106161 | 189.583471 | 0.687500 |
| geant | GEANT Core (SNDlib) | our_drl_dual_gate | 0.147808 | 0.172130 | 5.964934 | 1.000000 | 0.035871 | 44.562761 | 69.184215 | 99.828793 | 463.883067 | 0.687500 |
| geant | GEANT Core (SNDlib) | our_drl_ppo | 0.147808 | 0.172130 | 5.964934 | 1.000000 | 0.035871 | 44.562761 | 69.184215 | 38.275031 | 274.299596 | 0.687500 |
| geant | GEANT Core (SNDlib) | topk | 0.148984 | 0.174362 | 5.839406 | 1.000000 | 0.162275 | 45.739482 | 68.633191 | 25.637433 | nan | nan |
| geant | GEANT Core (SNDlib) | flexdate | 0.149124 | 0.175199 | 5.957555 | 1.000000 | 0.165078 | 45.758591 | 68.612277 | 25.902656 | nan | nan |
| geant | GEANT Core (SNDlib) | sensitivity | 0.149902 | 0.174800 | 5.735110 | 1.000000 | 0.204046 | 46.560284 | 68.238589 | 27.887762 | nan | nan |
| geant | GEANT Core (SNDlib) | erodrl | 0.149902 | 0.174800 | 5.706506 | 1.000000 | 0.198222 | 46.560284 | 68.238589 | 27.939420 | nan | nan |
| geant | GEANT Core (SNDlib) | flexentry | 0.150311 | 0.176223 | 5.787398 | 1.000000 | 0.169400 | 46.907046 | 68.074316 | 27.475341 | nan | nan |
| geant | GEANT Core (SNDlib) | ospf | 0.245699 | 0.291459 | 5.359968 | 1.000000 | 0.000000 | 140.335023 | 41.629635 | 0.000000 | nan | nan |
| geant | GEANT Core (SNDlib) | ecmp | 0.246957 | 0.291678 | 5.285395 | 1.000000 | 0.000000 | 141.658931 | 41.403527 | 0.000000 | nan | nan |
| rocketfuel_ebone | Ebone (Rocketfuel) | our_drl_dual_gate | 421.475089 | 475.576405 | 408.117807 | 1.000000 | 0.048633 | nan | nan | 104.938487 | 463.883067 | 0.687500 |
| rocketfuel_ebone | Ebone (Rocketfuel) | our_drl_ppo | 421.475089 | 475.576405 | 408.787009 | 1.000000 | 0.040170 | nan | nan | 40.658771 | 274.299596 | 0.687500 |
| rocketfuel_ebone | Ebone (Rocketfuel) | erodrl | 421.475089 | 475.576405 | 409.088008 | 1.000000 | 0.042281 | nan | nan | 29.970055 | nan | nan |
| rocketfuel_ebone | Ebone (Rocketfuel) | sensitivity | 421.475089 | 475.576405 | 408.909001 | 1.000000 | 0.043842 | nan | nan | 29.822478 | nan | nan |
| rocketfuel_ebone | Ebone (Rocketfuel) | bottleneck | 421.475089 | 475.576405 | 408.638715 | 1.000000 | 0.069561 | nan | nan | 29.369570 | nan | nan |
| rocketfuel_ebone | Ebone (Rocketfuel) | cfrrl | 421.475089 | 475.576405 | 408.638715 | 1.000000 | 0.069561 | nan | nan | 28.718557 | nan | nan |
| rocketfuel_ebone | Ebone (Rocketfuel) | our_drl_dqn | 421.475089 | 475.576405 | 407.519211 | 1.000000 | 0.027080 | nan | nan | 38.051287 | 189.583471 | 0.687500 |
| rocketfuel_ebone | Ebone (Rocketfuel) | flexentry | 421.475089 | 475.576405 | 408.432042 | 1.000000 | 0.033190 | nan | nan | 28.781745 | nan | nan |
| rocketfuel_ebone | Ebone (Rocketfuel) | topk | 421.475089 | 475.576405 | 410.788184 | 1.000000 | 0.070862 | nan | nan | 27.313304 | nan | nan |
| rocketfuel_ebone | Ebone (Rocketfuel) | flexdate | 421.475089 | 475.576405 | 408.127847 | 1.000000 | 0.065444 | nan | nan | 27.096195 | nan | nan |
| rocketfuel_ebone | Ebone (Rocketfuel) | ecmp | 465.312123 | 518.324941 | 399.676342 | 1.000000 | 0.000000 | nan | nan | 0.000000 | nan | nan |
| rocketfuel_ebone | Ebone (Rocketfuel) | ospf | 467.685303 | 520.700742 | 399.676342 | 1.000000 | 0.000000 | nan | nan | 0.000000 | nan | nan |
| rocketfuel_sprintlink | Sprintlink (Rocketfuel) | bottleneck | 942.799184 | 1116.606468 | 442.121590 | 1.000000 | 0.014727 | nan | nan | 44.414435 | nan | nan |
| rocketfuel_sprintlink | Sprintlink (Rocketfuel) | cfrrl | 942.799184 | 1116.606468 | 442.121590 | 1.000000 | 0.014727 | nan | nan | 44.318707 | nan | nan |
| rocketfuel_sprintlink | Sprintlink (Rocketfuel) | our_drl_dqn | 964.656838 | 1168.864901 | 441.979909 | 1.000000 | 0.046626 | nan | nan | 75.693863 | 189.583471 | 0.687500 |
| rocketfuel_sprintlink | Sprintlink (Rocketfuel) | our_drl_dual_gate | 964.664901 | 1201.149480 | 442.227606 | 1.000000 | 0.045760 | nan | nan | 190.916030 | 463.883067 | 0.687500 |
| rocketfuel_sprintlink | Sprintlink (Rocketfuel) | topk | 970.386902 | 1142.512720 | 444.586884 | 1.000000 | 0.027532 | nan | nan | 38.040872 | nan | nan |
| rocketfuel_sprintlink | Sprintlink (Rocketfuel) | our_drl_ppo | 974.552625 | 1222.021056 | 444.054495 | 1.000000 | 0.042445 | nan | nan | 78.513927 | 274.299596 | 0.687500 |
| rocketfuel_sprintlink | Sprintlink (Rocketfuel) | flexdate | 979.859114 | 1170.260724 | 441.273650 | 1.000000 | 0.020274 | nan | nan | 37.170429 | nan | nan |
| rocketfuel_sprintlink | Sprintlink (Rocketfuel) | erodrl | 991.902264 | 1173.675435 | 443.375621 | 1.000000 | 0.014394 | nan | nan | 46.137573 | nan | nan |
| rocketfuel_sprintlink | Sprintlink (Rocketfuel) | sensitivity | 996.252924 | 1189.821135 | 442.703779 | 1.000000 | 0.015222 | nan | nan | 46.099878 | nan | nan |
| rocketfuel_sprintlink | Sprintlink (Rocketfuel) | flexentry | 1064.987143 | 1252.214466 | 441.094701 | 1.000000 | 0.013344 | nan | nan | 45.555911 | nan | nan |
| rocketfuel_sprintlink | Sprintlink (Rocketfuel) | ecmp | 1148.696865 | 1348.524844 | 437.485218 | 1.000000 | 0.000000 | nan | nan | 0.000000 | nan | nan |
| rocketfuel_sprintlink | Sprintlink (Rocketfuel) | ospf | 1174.801235 | 1382.028555 | 437.485218 | 1.000000 | 0.000000 | nan | nan | 0.000000 | nan | nan |
| rocketfuel_tiscali | Tiscali (Rocketfuel) | erodrl | 844.764576 | 976.341510 | 485.214461 | 1.000000 | 0.021657 | nan | nan | 52.070250 | nan | nan |
| rocketfuel_tiscali | Tiscali (Rocketfuel) | sensitivity | 845.353484 | 976.341510 | 485.032933 | 1.000000 | 0.023997 | nan | nan | 52.174000 | nan | nan |
| rocketfuel_tiscali | Tiscali (Rocketfuel) | bottleneck | 846.864097 | 969.560253 | 483.799905 | 1.000000 | 0.020937 | nan | nan | 49.941216 | nan | nan |
| rocketfuel_tiscali | Tiscali (Rocketfuel) | cfrrl | 846.864097 | 969.560253 | 483.799905 | 1.000000 | 0.020937 | nan | nan | 50.086025 | nan | nan |
| rocketfuel_tiscali | Tiscali (Rocketfuel) | flexentry | 852.535612 | 984.178870 | 483.879822 | 1.000000 | 0.020376 | nan | nan | 51.723495 | nan | nan |
| rocketfuel_tiscali | Tiscali (Rocketfuel) | flexdate | 856.960252 | 965.832937 | 482.895635 | 1.000000 | 0.021100 | nan | nan | 40.768938 | nan | nan |
| rocketfuel_tiscali | Tiscali (Rocketfuel) | our_drl_dual_gate | 866.131929 | 994.528142 | 484.257908 | 1.000000 | 0.022665 | nan | nan | 220.790731 | 463.883067 | 0.687500 |
| rocketfuel_tiscali | Tiscali (Rocketfuel) | topk | 869.733007 | 980.187417 | 486.613729 | 1.000000 | 0.022314 | nan | nan | 40.034308 | nan | nan |
| rocketfuel_tiscali | Tiscali (Rocketfuel) | our_drl_ppo | 870.426531 | 1001.539455 | 486.979189 | 1.000000 | 0.010576 | nan | nan | 93.132871 | 274.299596 | 0.687500 |
| rocketfuel_tiscali | Tiscali (Rocketfuel) | our_drl_dqn | 871.926426 | 994.528142 | 481.611024 | 1.000000 | 0.010879 | nan | nan | 88.415829 | 189.583471 | 0.687500 |
| rocketfuel_tiscali | Tiscali (Rocketfuel) | ecmp | 883.856216 | 1001.539455 | 481.147129 | 1.000000 | 0.000000 | nan | nan | 0.000000 | nan | nan |
| rocketfuel_tiscali | Tiscali (Rocketfuel) | ospf | 1127.786730 | 1305.352934 | 481.147129 | 1.000000 | 0.000000 | nan | nan | 0.000000 | nan | nan |

## Improved DRL Selector Framework

- Teacher-guided pretraining: PPO and DQN are first warm-started from offline teacher labels built from Top-K, bottleneck, sensitivity, and sampled LP-optimal signals.
- Curriculum congestion training: training proceeds through C2, then C3, then mixed C1/C2/C3 stages with progressively richer reward terms.
- Dual-gate inference: PPO and DQN each propose Top-Kcrit OD selections; both are evaluated through the same LP layer; the lower-MLU candidate is chosen, with disturbance and delay tie-breakers.

## DRL Ablation Table

| variant | avg_mean_mlu | avg_p95_mlu | avg_mean_delay | avg_mean_disturbance |
| --- | --- | --- | --- | --- |
| PPO baseline | 453.121505 | 519.167749 | 267.117235 | 0.105176 |
| DQN baseline | 440.868995 | 497.542033 | 267.819460 | 0.086187 |
| PPO + pretraining | 447.997204 | 533.486197 | 268.217961 | 0.037549 |
| DQN + pretraining | 451.650104 | 527.838193 | 268.504012 | 0.041161 |
| PPO + pretraining + curriculum | 453.329282 | 539.871686 | 270.221258 | 0.051314 |
| DQN + pretraining + curriculum | 451.650104 | 527.838193 | 268.504012 | 0.041161 |
| Dual-Gate final | 450.492818 | 534.295109 | 269.181001 | 0.047580 |

## Dual-Gate Win Table

| dataset | dual_gate_mean_mlu | ppo_mean_mlu | dqn_mean_mlu | dual_beats_ppo | dual_beats_dqn |
| --- | --- | --- | --- | --- | --- |
| abilene | 0.044362 | 0.044357 | 0.044362 | False | False |
| geant | 0.147808 | 0.147808 | 0.147808 | False | False |
| rocketfuel_ebone | 421.475089 | 421.475089 | 421.475089 | True | True |
| rocketfuel_sprintlink | 964.664901 | 974.552625 | 964.656838 | True | False |
| rocketfuel_tiscali | 866.131929 | 870.426531 | 871.926426 | True | True |

## Gap To Best Heuristic+LP Baseline

| dataset | dual_gate_mean_mlu | best_heuristic | best_heuristic_mean_mlu | gap_pct_vs_best_heuristic |
| --- | --- | --- | --- | --- |
| abilene | 0.044362 | sensitivity | 0.044357 | 0.010460 |
| geant | 0.147808 | bottleneck | 0.146292 | 1.036410 |
| rocketfuel_ebone | 421.475089 | erodrl | 421.475089 | -0.000000 |
| rocketfuel_sprintlink | 964.664901 | bottleneck | 942.799184 | 2.319234 |
| rocketfuel_tiscali | 866.131929 | erodrl | 844.764576 | 2.529386 |

## LP-optimal Interpretation

- Use the wording `sampled LP-optimal upper bound` or `runtime-capped LP upper bound` in the thesis/report.
- This row comes from a full multicommodity-flow LP on sampled evaluation steps only, with a CBC runtime cap. In the full Phase-1 run it is executed only on tractable SNDlib topologies (Abilene and GEANT).

## Reproduced Literature Baselines

- `ERODRL`, `FlexDATE`, `CFR-RL`, and `FlexEntry` are faithful simplified reproductions, not exact official implementations.
| method | note |
| --- | --- |
| cfrrl | Simplified reproduced baseline: bottleneck selector reweighted by failure exposure when failures are active. |
| erodrl | Simplified reproduced baseline: sensitivity scoring with selection stickiness to approximate DRL rerouting. |
| flexdate | Simplified reproduced baseline: demand-and-delay weighted Top-K selector with LP refinement. |
| flexentry | Simplified reproduced baseline: sensitivity selector with a conservative reconfiguration budget. |

## Failure Scenarios

| dataset | failure_type | method | pre_failure_mean_mlu | post_failure_peak_mlu | post_failure_mean_mlu | failover_convergence_time_steps | route_change_frequency |
| --- | --- | --- | --- | --- | --- | --- | --- |
| abilene | capacity_degradation | cfrrl | 0.041128 | 0.049450 | 0.045904 | 0 | 1.000000 |
| abilene | capacity_degradation | sensitivity | 0.041128 | 0.049450 | 0.045914 | 0 | 1.000000 |
| abilene | capacity_degradation | bottleneck | 0.041128 | 0.049450 | 0.045920 | 0 | 1.000000 |
| abilene | capacity_degradation | flexdate | 0.041128 | 0.049450 | 0.045952 | 0 | 1.000000 |
| abilene | capacity_degradation | erodrl | 0.041128 | 0.049450 | 0.045959 | 0 | 1.000000 |
| abilene | capacity_degradation | topk | 0.041128 | 0.049450 | 0.046045 | 0 | 1.000000 |
| abilene | capacity_degradation | flexentry | 0.041358 | 0.049450 | 0.046084 | 0 | 1.000000 |
| abilene | capacity_degradation | our_drl_ppo | 0.041128 | 0.049450 | 0.046142 | 0 | 1.000000 |
| abilene | capacity_degradation | our_drl_dqn | 0.041129 | 0.049531 | 0.046219 | 0 | 1.000000 |
| abilene | capacity_degradation | our_drl_dual_gate | 0.041129 | 0.049531 | 0.046219 | 0 | 1.000000 |
| abilene | capacity_degradation | ospf | 0.055097 | 0.165915 | 0.139710 | -1 | 0.000000 |
| abilene | capacity_degradation | ecmp | 0.085261 | 0.233363 | 0.208215 | -1 | 0.000000 |
| abilene | multi_link_stress | bottleneck | 0.041128 | 0.098899 | 0.091775 | -1 | 1.000000 |
| abilene | multi_link_stress | cfrrl | 0.041128 | 0.098899 | 0.091775 | -1 | 1.000000 |
| abilene | multi_link_stress | our_drl_ppo | 0.041128 | 0.098899 | 0.091775 | -1 | 1.000000 |
| abilene | multi_link_stress | sensitivity | 0.041128 | 0.098899 | 0.091775 | -1 | 1.000000 |
| abilene | multi_link_stress | flexdate | 0.041128 | 0.098899 | 0.091775 | -1 | 1.000000 |
| abilene | multi_link_stress | topk | 0.041128 | 0.098899 | 0.091775 | -1 | 1.000000 |
| abilene | multi_link_stress | our_drl_dual_gate | 0.041129 | 0.098899 | 0.091775 | -1 | 1.000000 |
| abilene | multi_link_stress | our_drl_dqn | 0.041129 | 0.098899 | 0.091775 | -1 | 1.000000 |
| abilene | multi_link_stress | flexentry | 0.041358 | 0.098899 | 0.091775 | -1 | 1.000000 |
| abilene | multi_link_stress | erodrl | 0.041128 | 0.098899 | 0.091775 | -1 | 1.000000 |
| abilene | multi_link_stress | ospf | 0.055097 | 0.127224 | 0.105247 | -1 | 0.000000 |
| abilene | multi_link_stress | ecmp | 0.085261 | 0.184688 | 0.156368 | -1 | 0.052632 |
| abilene | single_link_failure | flexdate | 0.041128 | 0.049450 | 0.046020 | 0 | 1.000000 |
| abilene | single_link_failure | bottleneck | 0.041128 | 0.049450 | 0.046020 | 0 | 1.000000 |
| abilene | single_link_failure | cfrrl | 0.041128 | 0.049450 | 0.046020 | 0 | 1.000000 |
| abilene | single_link_failure | topk | 0.041128 | 0.050086 | 0.046141 | 0 | 1.000000 |
| abilene | single_link_failure | erodrl | 0.041128 | 0.049704 | 0.046159 | 0 | 1.000000 |
| abilene | single_link_failure | sensitivity | 0.041128 | 0.049704 | 0.046159 | 0 | 1.000000 |
| abilene | single_link_failure | our_drl_ppo | 0.041128 | 0.050086 | 0.046219 | 0 | 1.000000 |
| abilene | single_link_failure | our_drl_dqn | 0.041129 | 0.050425 | 0.046366 | 0 | 1.000000 |
| abilene | single_link_failure | our_drl_dual_gate | 0.041129 | 0.050425 | 0.046366 | 0 | 1.000000 |
| abilene | single_link_failure | flexentry | 0.041358 | 0.064737 | 0.047824 | 1 | 1.000000 |
| abilene | single_link_failure | ospf | 0.055097 | 0.064895 | 0.055947 | 0 | 0.000000 |
| abilene | single_link_failure | ecmp | 0.085261 | 0.087397 | 0.060135 | 0 | 0.052632 |
| geant | capacity_degradation | cfrrl | 0.123664 | 0.226687 | 0.208384 | -1 | 1.000000 |
| geant | capacity_degradation | bottleneck | 0.123664 | 0.227262 | 0.208744 | -1 | 1.000000 |
| geant | capacity_degradation | our_drl_dual_gate | 0.124390 | 0.231288 | 0.211867 | -1 | 1.000000 |
| geant | capacity_degradation | our_drl_ppo | 0.124390 | 0.231288 | 0.211867 | -1 | 1.000000 |
| geant | capacity_degradation | our_drl_dqn | 0.124390 | 0.231288 | 0.211867 | -1 | 1.000000 |
| geant | capacity_degradation | topk | 0.125543 | 0.234555 | 0.213451 | -1 | 1.000000 |
| geant | capacity_degradation | flexdate | 0.124733 | 0.234555 | 0.214237 | -1 | 1.000000 |
| geant | capacity_degradation | erodrl | 0.125543 | 0.234555 | 0.215255 | -1 | 1.000000 |
| geant | capacity_degradation | sensitivity | 0.125543 | 0.234555 | 0.215255 | -1 | 1.000000 |
| geant | capacity_degradation | flexentry | 0.125543 | 0.236973 | 0.216058 | -1 | 1.000000 |
| geant | capacity_degradation | ospf | 0.208415 | 0.571989 | 0.520951 | -1 | 0.000000 |
| geant | capacity_degradation | ecmp | 0.210375 | 0.572037 | 0.523997 | -1 | 0.000000 |
| geant | multi_link_stress | sensitivity | 0.125543 | 0.183582 | 0.166451 | -1 | 1.000000 |
| geant | multi_link_stress | erodrl | 0.125543 | 0.183582 | 0.166451 | -1 | 1.000000 |
| geant | multi_link_stress | bottleneck | 0.123664 | 0.183582 | 0.166477 | -1 | 1.000000 |
| geant | multi_link_stress | cfrrl | 0.123664 | 0.183582 | 0.166477 | -1 | 1.000000 |
| geant | multi_link_stress | flexdate | 0.124733 | 0.183582 | 0.166477 | -1 | 1.000000 |
| geant | multi_link_stress | our_drl_dqn | 0.124390 | 0.183582 | 0.166643 | -1 | 1.000000 |
| geant | multi_link_stress | flexentry | 0.125543 | 0.183582 | 0.166643 | -1 | 1.000000 |
| geant | multi_link_stress | topk | 0.125543 | 0.183582 | 0.166643 | -1 | 1.000000 |
| geant | multi_link_stress | our_drl_dual_gate | 0.124390 | 0.183582 | 0.166643 | -1 | 1.000000 |
| geant | multi_link_stress | our_drl_ppo | 0.124390 | 0.183582 | 0.166643 | -1 | 1.000000 |
| geant | multi_link_stress | ospf | 0.208415 | 0.222350 | 0.204980 | 0 | 0.000000 |
| geant | multi_link_stress | ecmp | 0.210375 | 0.278646 | 0.242211 | 0 | 0.052632 |
| geant | single_link_failure | sensitivity | 0.125543 | 0.183582 | 0.166441 | -1 | 1.000000 |
| geant | single_link_failure | erodrl | 0.125543 | 0.183582 | 0.166441 | -1 | 1.000000 |
| geant | single_link_failure | flexdate | 0.124733 | 0.183582 | 0.166467 | -1 | 1.000000 |
| geant | single_link_failure | bottleneck | 0.123664 | 0.183582 | 0.166467 | -1 | 1.000000 |
| geant | single_link_failure | cfrrl | 0.123664 | 0.183582 | 0.166467 | -1 | 1.000000 |
| geant | single_link_failure | flexentry | 0.125543 | 0.183582 | 0.166629 | -1 | 1.000000 |
| geant | single_link_failure | topk | 0.125543 | 0.183582 | 0.166629 | -1 | 1.000000 |
| geant | single_link_failure | our_drl_dqn | 0.124390 | 0.183582 | 0.166629 | -1 | 1.000000 |
| geant | single_link_failure | our_drl_dual_gate | 0.124390 | 0.183582 | 0.166629 | -1 | 1.000000 |
| geant | single_link_failure | our_drl_ppo | 0.124390 | 0.183582 | 0.166629 | -1 | 1.000000 |
| geant | single_link_failure | ospf | 0.208415 | 0.222350 | 0.204790 | 0 | 0.000000 |
| geant | single_link_failure | ecmp | 0.210375 | 0.264691 | 0.241185 | 0 | 0.052632 |
| rocketfuel_ebone | capacity_degradation | cfrrl | 454.408228 | 553.212116 | 541.166908 | -1 | 1.000000 |
| rocketfuel_ebone | capacity_degradation | sensitivity | 454.408228 | 553.212117 | 541.166909 | -1 | 1.000000 |
| rocketfuel_ebone | capacity_degradation | bottleneck | 454.408228 | 553.212117 | 541.166909 | -1 | 1.000000 |
| rocketfuel_ebone | capacity_degradation | erodrl | 454.408228 | 564.241931 | 542.904737 | -1 | 1.000000 |
| rocketfuel_ebone | capacity_degradation | flexentry | 454.408228 | 611.847557 | 577.511519 | -1 | 1.000000 |
| rocketfuel_ebone | capacity_degradation | flexdate | 454.408228 | 655.027771 | 582.112622 | -1 | 1.000000 |
| rocketfuel_ebone | capacity_degradation | our_drl_dual_gate | 454.408228 | 754.149656 | 625.994940 | -1 | 1.000000 |
| rocketfuel_ebone | capacity_degradation | our_drl_ppo | 454.408228 | 763.851997 | 632.032533 | -1 | 1.000000 |
| rocketfuel_ebone | capacity_degradation | our_drl_dqn | 454.408228 | 777.032714 | 654.725836 | -1 | 1.000000 |
| rocketfuel_ebone | capacity_degradation | topk | 454.408228 | 751.646607 | 667.097814 | -1 | 1.000000 |
| rocketfuel_ebone | capacity_degradation | ecmp | 493.660360 | 936.861513 | 903.768021 | -1 | 0.000000 |
| rocketfuel_ebone | capacity_degradation | ospf | 498.820340 | 937.710596 | 905.874256 | -1 | 0.000000 |
| rocketfuel_ebone | multi_link_stress | bottleneck | 454.408228 | 307.618014 | 279.178174 | 0 | 1.000000 |
| rocketfuel_ebone | multi_link_stress | cfrrl | 454.408228 | 307.618014 | 279.178174 | 0 | 1.000000 |
| rocketfuel_ebone | multi_link_stress | sensitivity | 454.408228 | 307.618014 | 279.178174 | 0 | 1.000000 |
| rocketfuel_ebone | multi_link_stress | erodrl | 454.408228 | 307.618014 | 279.286866 | 0 | 1.000000 |
| rocketfuel_ebone | multi_link_stress | our_drl_ppo | 454.408228 | 307.618014 | 279.532334 | 0 | 1.000000 |
| rocketfuel_ebone | multi_link_stress | flexdate | 454.408228 | 307.618014 | 279.681010 | 0 | 1.000000 |
| rocketfuel_ebone | multi_link_stress | our_drl_dual_gate | 454.408228 | 307.618014 | 280.330654 | 0 | 1.000000 |
| rocketfuel_ebone | multi_link_stress | our_drl_dqn | 454.408228 | 307.618014 | 280.750848 | 0 | 1.000000 |
| rocketfuel_ebone | multi_link_stress | flexentry | 454.408228 | 307.618014 | 281.069096 | 0 | 1.000000 |
| rocketfuel_ebone | multi_link_stress | topk | 454.408228 | 307.618014 | 292.028024 | 0 | 1.000000 |
| rocketfuel_ebone | multi_link_stress | ecmp | 493.660360 | 367.866149 | 332.258568 | 0 | 0.052632 |
| rocketfuel_ebone | multi_link_stress | ospf | 498.820340 | 380.623554 | 354.811113 | 0 | 0.052632 |
| rocketfuel_ebone | single_link_failure | bottleneck | 454.408228 | 829.818175 | 811.750363 | -1 | 1.000000 |
| rocketfuel_ebone | single_link_failure | cfrrl | 454.408228 | 829.818175 | 811.750363 | -1 | 1.000000 |
| rocketfuel_ebone | single_link_failure | ecmp | 493.660360 | 829.818175 | 811.750363 | -1 | 0.052632 |
| rocketfuel_ebone | single_link_failure | erodrl | 454.408228 | 829.818175 | 811.750363 | -1 | 1.000000 |
| rocketfuel_ebone | single_link_failure | flexdate | 454.408228 | 829.818175 | 811.750363 | -1 | 1.000000 |
| rocketfuel_ebone | single_link_failure | flexentry | 454.408228 | 829.818175 | 811.750363 | -1 | 1.000000 |
| rocketfuel_ebone | single_link_failure | ospf | 498.820340 | 829.818175 | 811.750363 | -1 | 0.000000 |
| rocketfuel_ebone | single_link_failure | our_drl_dqn | 454.408228 | 829.818175 | 811.750363 | -1 | 1.000000 |
| rocketfuel_ebone | single_link_failure | our_drl_dual_gate | 454.408228 | 829.818175 | 811.750363 | -1 | 0.894737 |
| rocketfuel_ebone | single_link_failure | our_drl_ppo | 454.408228 | 829.818175 | 811.750363 | -1 | 0.736842 |
| rocketfuel_ebone | single_link_failure | sensitivity | 454.408228 | 829.818175 | 811.750363 | -1 | 0.947368 |
| rocketfuel_ebone | single_link_failure | topk | 454.408228 | 829.818175 | 811.750363 | -1 | 1.000000 |
| rocketfuel_sprintlink | capacity_degradation | our_drl_dual_gate | 1031.207149 | 1677.783558 | 1554.113379 | -1 | 1.000000 |
| rocketfuel_sprintlink | capacity_degradation | our_drl_dqn | 1050.570278 | 1677.783558 | 1578.434646 | -1 | 0.894737 |
| rocketfuel_sprintlink | capacity_degradation | cfrrl | 1033.853418 | 1679.726009 | 1614.692352 | -1 | 1.000000 |
| rocketfuel_sprintlink | capacity_degradation | our_drl_ppo | 1050.782392 | 1723.915442 | 1619.669218 | -1 | 1.000000 |
| rocketfuel_sprintlink | capacity_degradation | bottleneck | 1033.853418 | 1738.035115 | 1663.090117 | -1 | 1.000000 |
| rocketfuel_sprintlink | capacity_degradation | topk | 1063.912163 | 1946.935598 | 1852.170926 | -1 | 1.000000 |
| rocketfuel_sprintlink | capacity_degradation | flexdate | 1075.883467 | 1988.154015 | 1868.747787 | -1 | 1.000000 |
| rocketfuel_sprintlink | capacity_degradation | erodrl | 1082.885190 | 2063.239594 | 1909.456978 | -1 | 1.000000 |
| rocketfuel_sprintlink | capacity_degradation | sensitivity | 1089.401880 | 2063.239594 | 1914.535806 | -1 | 1.000000 |
| rocketfuel_sprintlink | capacity_degradation | flexentry | 1160.817398 | 2174.591692 | 2102.481415 | -1 | 1.000000 |
| rocketfuel_sprintlink | capacity_degradation | ecmp | 1260.711354 | 2267.634863 | 2191.274740 | -1 | 0.000000 |
| rocketfuel_sprintlink | capacity_degradation | ospf | 1290.441981 | 2321.126340 | 2240.048078 | -1 | 0.000000 |
| rocketfuel_sprintlink | multi_link_stress | bottleneck | 1033.853418 | 1395.046994 | 1346.545040 | -1 | 1.000000 |
| rocketfuel_sprintlink | multi_link_stress | cfrrl | 1033.853418 | 1395.046994 | 1346.545040 | -1 | 1.000000 |
| rocketfuel_sprintlink | multi_link_stress | erodrl | 1082.885190 | 1395.046994 | 1346.545040 | -1 | 1.000000 |
| rocketfuel_sprintlink | multi_link_stress | flexdate | 1075.883467 | 1395.046994 | 1346.545040 | -1 | 1.000000 |
| rocketfuel_sprintlink | multi_link_stress | flexentry | 1160.817398 | 1395.046994 | 1346.545040 | -1 | 1.000000 |
| rocketfuel_sprintlink | multi_link_stress | our_drl_dqn | 1050.570278 | 1395.046994 | 1346.545040 | -1 | 1.000000 |
| rocketfuel_sprintlink | multi_link_stress | sensitivity | 1089.401880 | 1395.046994 | 1346.545040 | -1 | 1.000000 |
| rocketfuel_sprintlink | multi_link_stress | topk | 1063.912163 | 1395.046994 | 1346.545040 | -1 | 1.000000 |
| rocketfuel_sprintlink | multi_link_stress | ecmp | 1260.711354 | 1395.046994 | 1346.545040 | 6 | 0.052632 |
| rocketfuel_sprintlink | multi_link_stress | ospf | 1290.441981 | 1395.046994 | 1346.545040 | 5 | 0.000000 |
| rocketfuel_sprintlink | multi_link_stress | our_drl_dual_gate | 1031.207149 | 1395.046994 | 1346.545040 | -1 | 1.000000 |
| rocketfuel_sprintlink | multi_link_stress | our_drl_ppo | 1050.782392 | 1395.046994 | 1346.545040 | -1 | 1.000000 |
| rocketfuel_sprintlink | single_link_failure | our_drl_dual_gate | 1031.207149 | 1400.435115 | 1352.044601 | -1 | 0.789474 |
| rocketfuel_sprintlink | single_link_failure | our_drl_ppo | 1050.782392 | 1400.435115 | 1352.044601 | -1 | 0.842105 |
| rocketfuel_sprintlink | single_link_failure | our_drl_dqn | 1050.570278 | 1400.435115 | 1352.366996 | -1 | 0.947368 |
| rocketfuel_sprintlink | single_link_failure | bottleneck | 1033.853418 | 1438.000571 | 1397.803585 | -1 | 1.000000 |
| rocketfuel_sprintlink | single_link_failure | cfrrl | 1033.853418 | 1438.000571 | 1397.803585 | -1 | 1.000000 |
| rocketfuel_sprintlink | single_link_failure | flexdate | 1075.883467 | 1445.805622 | 1399.272712 | -1 | 1.000000 |
| rocketfuel_sprintlink | single_link_failure | ecmp | 1260.711354 | 1455.925384 | 1405.748678 | -1 | 0.052632 |
| rocketfuel_sprintlink | single_link_failure | erodrl | 1082.885190 | 1455.925384 | 1405.748678 | -1 | 1.000000 |
| rocketfuel_sprintlink | single_link_failure | flexentry | 1160.817398 | 1455.925384 | 1405.748678 | -1 | 1.000000 |
| rocketfuel_sprintlink | single_link_failure | sensitivity | 1089.401880 | 1455.925384 | 1405.748678 | -1 | 1.000000 |
| rocketfuel_sprintlink | single_link_failure | topk | 1063.912163 | 1455.925384 | 1405.748678 | -1 | 1.000000 |
| rocketfuel_sprintlink | single_link_failure | ospf | 1290.441981 | 1507.446381 | 1451.395945 | -1 | 0.000000 |
| rocketfuel_tiscali | capacity_degradation | cfrrl | 912.154325 | 1055.678234 | 1005.534695 | 4 | 1.000000 |
| rocketfuel_tiscali | capacity_degradation | our_drl_ppo | 938.984038 | 1545.863755 | 1194.643986 | 3 | 1.000000 |
| rocketfuel_tiscali | capacity_degradation | our_drl_dual_gate | 929.493491 | 1560.535972 | 1195.093714 | 5 | 1.000000 |
| rocketfuel_tiscali | capacity_degradation | bottleneck | 912.154325 | 1361.565624 | 1247.610097 | -1 | 1.000000 |
| rocketfuel_tiscali | capacity_degradation | our_drl_dqn | 942.504408 | 1658.702071 | 1302.265090 | 4 | 1.000000 |
| rocketfuel_tiscali | capacity_degradation | sensitivity | 910.671624 | 1391.872433 | 1347.731956 | -1 | 1.000000 |
| rocketfuel_tiscali | capacity_degradation | erodrl | 910.671624 | 1411.994234 | 1364.571935 | -1 | 1.000000 |
| rocketfuel_tiscali | capacity_degradation | flexentry | 923.046969 | 1466.154329 | 1382.747301 | -1 | 1.000000 |
| rocketfuel_tiscali | capacity_degradation | topk | 926.298930 | 1512.781091 | 1417.331750 | -1 | 1.000000 |
| rocketfuel_tiscali | capacity_degradation | flexdate | 909.852248 | 1608.468915 | 1522.378240 | -1 | 1.000000 |
| rocketfuel_tiscali | capacity_degradation | ecmp | 952.731044 | 1724.199763 | 1632.050583 | -1 | 0.000000 |
| rocketfuel_tiscali | capacity_degradation | ospf | 1242.781277 | 2254.534065 | 2146.631259 | -1 | 0.000000 |
| rocketfuel_tiscali | multi_link_stress | bottleneck | 912.154325 | 983.793363 | 938.909672 | 1 | 1.000000 |
| rocketfuel_tiscali | multi_link_stress | cfrrl | 912.154325 | 983.793363 | 938.909672 | 1 | 1.000000 |
| rocketfuel_tiscali | multi_link_stress | sensitivity | 910.671624 | 1043.542789 | 968.682162 | 1 | 1.000000 |
| rocketfuel_tiscali | multi_link_stress | our_drl_dual_gate | 929.493491 | 1157.280909 | 968.835246 | 0 | 1.000000 |
| rocketfuel_tiscali | multi_link_stress | our_drl_dqn | 942.504408 | 1168.945892 | 971.286559 | 0 | 1.000000 |
| rocketfuel_tiscali | multi_link_stress | erodrl | 910.671624 | 1043.542789 | 972.513771 | 1 | 1.000000 |
| rocketfuel_tiscali | multi_link_stress | our_drl_ppo | 938.984038 | 1176.203237 | 974.559578 | 0 | 1.000000 |
| rocketfuel_tiscali | multi_link_stress | flexentry | 923.046969 | 1062.014064 | 995.711712 | 4 | 1.000000 |
| rocketfuel_tiscali | multi_link_stress | topk | 926.298930 | 1077.832863 | 1012.583470 | 7 | 1.000000 |
| rocketfuel_tiscali | multi_link_stress | flexdate | 909.852248 | 1082.626386 | 1018.130233 | -1 | 1.000000 |
| rocketfuel_tiscali | multi_link_stress | ospf | 1242.781277 | 1158.803228 | 1107.438028 | 0 | 0.000000 |
| rocketfuel_tiscali | multi_link_stress | ecmp | 952.731044 | 1184.169445 | 1125.065758 | -1 | 0.052632 |
| rocketfuel_tiscali | single_link_failure | our_drl_dqn | 942.504408 | 1073.983755 | 923.523463 | 0 | 1.000000 |
| rocketfuel_tiscali | single_link_failure | bottleneck | 912.154325 | 984.503698 | 936.961572 | 0 | 1.000000 |
| rocketfuel_tiscali | single_link_failure | cfrrl | 912.154325 | 984.503698 | 936.961572 | 0 | 1.000000 |
| rocketfuel_tiscali | single_link_failure | our_drl_dual_gate | 929.493491 | 1003.715325 | 937.665300 | 0 | 1.000000 |
| rocketfuel_tiscali | single_link_failure | our_drl_ppo | 938.984038 | 1003.715325 | 937.665300 | 0 | 1.000000 |
| rocketfuel_tiscali | single_link_failure | sensitivity | 910.671624 | 1024.890316 | 964.980418 | 0 | 1.000000 |
| rocketfuel_tiscali | single_link_failure | erodrl | 910.671624 | 1033.855226 | 980.716620 | 4 | 1.000000 |
| rocketfuel_tiscali | single_link_failure | flexentry | 923.046969 | 1044.633937 | 987.108314 | 4 | 1.000000 |
| rocketfuel_tiscali | single_link_failure | topk | 926.298930 | 1052.848062 | 997.895463 | 4 | 1.000000 |
| rocketfuel_tiscali | single_link_failure | flexdate | 909.852248 | 1079.922232 | 1002.783215 | -1 | 1.000000 |
| rocketfuel_tiscali | single_link_failure | ecmp | 952.731044 | 1102.132540 | 1033.025436 | -1 | 0.052632 |
| rocketfuel_tiscali | single_link_failure | ospf | 1242.781277 | 1084.819130 | 1043.816306 | 0 | 0.000000 |

## Dataset Execution Status

- `germany50_real` was executed as the unseen generalization topology.
- `germany50_topologyzoo_real` was not executed because the external real traffic matrix file is missing.
- `cernet_real` was not executed because the external real traffic matrix file is missing.

## Generalization on Unseen Topologies

- Final generalization uses the corrected unseen split; `germany50_real` does not appear in `train_topologies` or `eval_topologies` in the corrected full config.
| train_scope | dataset | display_name | method | mean_mlu | mean_delay | mean_disturbance |
| --- | --- | --- | --- | --- | --- | --- |
| abilene_backbone,geant_core,ebone,sprintlink,tiscali,vtlwavenet2011 | germany50 | Germany50 (SNDlib real traffic) | flexdate | 21.935045 | 530.883367 | 0.216007 |
| abilene_backbone,geant_core,ebone,sprintlink,tiscali,vtlwavenet2011 | germany50 | Germany50 (SNDlib real traffic) | bottleneck | 22.214560 | 531.957167 | 0.171446 |
| abilene_backbone,geant_core,ebone,sprintlink,tiscali,vtlwavenet2011 | germany50 | Germany50 (SNDlib real traffic) | cfrrl | 22.214560 | 531.957167 | 0.171446 |
| abilene_backbone,geant_core,ebone,sprintlink,tiscali,vtlwavenet2011 | germany50 | Germany50 (SNDlib real traffic) | topk | 22.248924 | 535.951439 | 0.190347 |
| abilene_backbone,geant_core,ebone,sprintlink,tiscali,vtlwavenet2011 | germany50 | Germany50 (SNDlib real traffic) | erodrl | 23.953543 | 536.551033 | 0.156833 |
| abilene_backbone,geant_core,ebone,sprintlink,tiscali,vtlwavenet2011 | germany50 | Germany50 (SNDlib real traffic) | sensitivity | 24.525642 | 536.962921 | 0.204778 |
| abilene_backbone,geant_core,ebone,sprintlink,tiscali,vtlwavenet2011 | germany50 | Germany50 (SNDlib real traffic) | flexentry | 24.932882 | 540.817461 | 0.169928 |
| abilene_backbone,geant_core,ebone,sprintlink,tiscali,vtlwavenet2011 | germany50 | Germany50 (SNDlib real traffic) | our_drl_dqn | 31.747248 | 520.607758 | 0.024820 |
| abilene_backbone,geant_core,ebone,sprintlink,tiscali,vtlwavenet2011 | germany50 | Germany50 (SNDlib real traffic) | our_drl_dual_gate | 31.748217 | 520.613625 | 0.022927 |
| abilene_backbone,geant_core,ebone,sprintlink,tiscali,vtlwavenet2011 | germany50 | Germany50 (SNDlib real traffic) | our_drl_ppo | 31.985414 | 520.683206 | 0.018043 |
| abilene_backbone,geant_core,ebone,sprintlink,tiscali,vtlwavenet2011 | germany50 | Germany50 (SNDlib real traffic) | ecmp | 32.198400 | 520.703500 | 0.000000 |
| abilene_backbone,geant_core,ebone,sprintlink,tiscali,vtlwavenet2011 | germany50 | Germany50 (SNDlib real traffic) | ospf | 38.270430 | 519.710429 | 0.000000 |

## Honest Outcome Summary

| dataset | best_drl_method | best_drl_mean_mlu | beats_ospf | beats_ecmp | beats_best_heuristic |
| --- | --- | --- | --- | --- | --- |
| abilene | our_drl_ppo | 0.044357 | True | True | False |
| geant | our_drl_dqn | 0.147808 | True | True | False |
| rocketfuel_ebone | our_drl_dual_gate | 421.475089 | True | True | True |
| rocketfuel_sprintlink | our_drl_dqn | 964.656838 | True | True | False |
| rocketfuel_tiscali | our_drl_dual_gate | 866.131929 | True | True | False |
